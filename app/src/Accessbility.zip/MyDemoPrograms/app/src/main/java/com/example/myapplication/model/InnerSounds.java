package com.example.myapplication.model;

public class InnerSounds {
    public String link;
    public String image;
}
