package com.example.myapplication.model

object UserInput {

    fun uservalues(){}
}