package com.example.myapplication.interfaces;

import com.example.myapplication.model.InnerSounds;

public interface ListItemAction {
    public void onClick(InnerSounds innerSounds, int position);
}
