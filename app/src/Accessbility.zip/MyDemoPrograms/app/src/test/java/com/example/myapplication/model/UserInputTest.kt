package com.example.myapplication.model

import junit.framework.TestCase
import org.junit.Test

class UserInputTest : TestCase(){
    @Test
    fun checkInput(){

    }
}